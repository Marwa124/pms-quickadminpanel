<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMilestonesTable extends Migration
{
    public function up()
    {
        Schema::create('milestones', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name')->unique();
            $table->date('start_date');
            $table->date('end_date');
            $table->longText('client_visible')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}
